import React, { useState } from "react";

/**
 * NexGenix — Navbar & Hero replica (v3, responsive)
 * -------------------------------------------------
 * Updates:
 *  - Mobile-first responsive layout (stacks hero, adjusts paddings, fluid type).
 *  - Accessible mobile menu (hamburger) with focus styles.
 *  - Logo uploader kept; shows placeholder until you pick an image.
 *  - Media section: YouTube embed with autoplay (muted) + anchor wrapper.
 *
 * To replace the video: put your YouTube share link's ID in `YOUTUBE_ID`.
 */

function Nav() {
  const [logoPath, setLogoPath] = useState("");
  const [open, setOpen] = useState(false); // mobile menu toggle

  return (
    <header className="w-full">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between">
        {/* LOGO + UPLOADER */}
        <div className="flex items-center gap-3 min-w-0">
          {logoPath ? (
            <img src={logoPath} alt="Company Logo" className="w-10 h-10 sm:w-12 sm:h-12 object-contain rounded" />
          ) : (
            <div className="w-10 h-10 sm:w-12 sm:h-12 border border-dashed border-gray-400 flex items-center justify-center text-[10px] sm:text-xs text-gray-500 rounded-md">
              Logo
            </div>
          )}
          <input
            type="file"
            accept="image/*"
            aria-label="Upload logo"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) setLogoPath(URL.createObjectURL(file));
            }}
            className="text-[10px] sm:text-xs text-gray-600 max-w-[140px] truncate"
          />
          <span className="hidden sm:inline font-semibold text-[#2b0a3a] tracking-tight">NexGenix</span>
        </div>

        {/* DESKTOP NAV */}
        <nav className="hidden md:block">
          <ul className="flex items-center gap-8 lg:gap-10 text-sm text-[#2b0a3a]">
            <li><a className="hover:opacity-80" href="#">Home</a></li>
            <li><a className="hover:opacity-80" href="#">About us</a></li>
            <li><a className="hover:opacity-80" href="#">Our services</a></li>
            <li><a className="hover:opacity-80" href="#">Our works</a></li>
          </ul>
        </nav>

        {/* CONTACT + HAMBURGER */}
        <div className="flex items-center gap-3">
          <a
            href="#contact"
            className="hidden sm:inline rounded-xl border border-[#e4cfe2] text-[#2b0a3a] px-4 py-2 text-sm hover:shadow-sm"
          >
            Contact us
          </a>
          <button
            type="button"
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
            className="md:hidden inline-flex items-center justify-center rounded-lg p-2 ring-1 ring-[#e4cfe2] text-[#2b0a3a]"
          >
            <span className="sr-only">Open menu</span>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
          </button>
        </div>
      </div>

      {/* MOBILE MENU */}
      {open && (
        <div className="md:hidden border-t border-[#e9dde7]">
          <ul className="px-4 py-3 space-y-2 text-sm text-[#2b0a3a]">
            <li><a className="block py-2" href="#">Home</a></li>
            <li><a className="block py-2" href="#">About us</a></li>
            <li><a className="block py-2" href="#">Our services</a></li>
            <li><a className="block py-2" href="#">Our works</a></li>
            <li>
              <a href="#contact" className="inline-block mt-2 rounded-xl border border-[#e4cfe2] px-4 py-2">Contact us</a>
            </li>
          </ul>
        </div>
      )}
      <div className="h-px w-full bg-[#e9dde7]" />
    </header>
  );
}

function Hero() {
  // Replace this with your YouTube video ID
  const YOUTUBE_ID = "dQw4w9WgXcQ";
  const params = "?autoplay=1&mute=1&rel=0&modestbranding=1&playsinline=1";
  const videoLink = `https://www.youtube.com/embed/${YOUTUBE_ID}${params}`;

  return (
    <section className="relative">
      {/* dotted curve bg */}
      <svg className="pointer-events-none absolute inset-0 -z-10 h-full w-full" viewBox="0 0 1440 600" preserveAspectRatio="none">
        <path d="M0,420 C240,300 480,480 720,360 C960,240 1200,420 1440,300" fill="none" stroke="#d9cddd" strokeDasharray="4 10" strokeWidth="3" />
      </svg>

      {/* content grid */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12 sm:py-16 lg:py-20 grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 items-center">
        {/* LEFT — TEXT */}
        <div className="flex flex-col justify-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-[#2b0a3a]">
            Social media marketing
          </h1>
          <p className="mt-4 sm:mt-6 max-w-2xl leading-7 text-[#4d3a56]">
            With our unique blend of creativity, strategy, and dedication, we make your brand stand out in a crowded online space.
            Whether you’re looking to boost brand awareness or generate leads, we’re here to make it happen.
          </p>
        </div>

        {/* RIGHT — MEDIA (responsive iframe within framed card) */}
        <div className="w-full lg:max-w-[540px] justify-self-center">
          <div className="rounded-3xl border-[6px] border-[#2b0a3a]/90 p-2 sm:p-3 shadow-[0_10px_30px_rgba(0,0,0,0.08)] bg-white">
            <div className="relative overflow-hidden rounded-2xl aspect-video">
              <a href={videoLink} target="_blank" rel="noopener noreferrer" aria-label="Open video in new tab">
                <iframe
                  className="w-full h-full"
                  src={videoLink}
                  title="Promotional Video"
                  allow="autoplay; encrypted-media; picture-in-picture"
                  allowFullScreen
                />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-[#fbf7fb] text-[#1d0b27]">
      <Nav />
      <Hero />
    </div>
  );
}
